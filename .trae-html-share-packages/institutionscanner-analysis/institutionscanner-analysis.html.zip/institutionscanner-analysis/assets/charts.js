(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart 1: 模块代码量分布 ---
  var chart1 = echarts.init(document.getElementById('chart-module-lines'), null, { renderer: 'svg' });
  var modules = ['analytics', 'gui_core', 'scanner', 'signal_lifecycle', 'score', 'report', 'downloader', 'fundamental_data', 'indicators', 'gui', 'filters', 'main', 'config', 'performance_cache', 'model_calibration', 'scan_service', 'fundamental_quality', 'network_proxy'];
  var lines = [2472, 2196, 1299, 1158, 1013, 730, 729, 644, 577, 531, 508, 447, 335, 315, 313, 214, 231, 88];
  var categories = ['回测引擎', 'GUI核心', '扫描编排', '信号生命周期', '评分引擎', '报告生成', '数据下载', '基本面数据', '技术指标', 'GUI决策', '筛选器', 'CLI入口', '配置', '性能缓存', '模型校准', '扫描服务', '基本面质量', '网络代理'];

  chart1.setOption({
    animation: false,
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, appendToBody: true },
    grid: { left: 140, right: 40, top: 20, bottom: 20 },
    xAxis: { type: 'value', name: '行数', nameTextStyle: { color: muted }, axisLine: { lineStyle: { color: rule } }, axisLabel: { color: muted } },
    yAxis: { type: 'category', data: categories.reverse(), axisLine: { lineStyle: { color: rule } }, axisLabel: { color: ink, fontSize: 12 }, inverse: true },
    series: [{
      type: 'bar', data: modules.map(function(m, i) { return { name: categories[i], value: lines[i] }; }).reverse(),
      itemStyle: {
        color: function(p) {
          var v = p.value;
          if (v > 1500) return accent;
          if (v > 700) return accent2;
          return muted;
        }
      },
      label: { show: true, position: 'right', color: muted, fontSize: 11 }
    }]
  });
  window.addEventListener('resize', function() { chart1.resize(); });

  // --- Chart 2: 评分维度权重 ---
  var chart2 = echarts.init(document.getElementById('chart-scoring-weights'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    tooltip: { trigger: 'item', appendToBody: true },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      center: ['50%', '50%'],
      label: { color: ink, fontSize: 13 },
      emphasis: { label: { fontWeight: 'bold' } },
      data: [
        { value: 20, name: '趋势 (Trend)', itemStyle: { color: accent } },
        { value: 25, name: '成交量 (Volume)', itemStyle: { color: accent2 } },
        { value: 25, name: '吸筹 (Accumulation)', itemStyle: { color: '#d2a8ff' } },
        { value: 15, name: '波动率 (Volatility)', itemStyle: { color: '#f0883e' } },
        { value: 15, name: '结构 (Structure)', itemStyle: { color: '#79c0ff' } }
      ]
    }]
  });
  window.addEventListener('resize', function() { chart2.resize(); });

  // --- Chart 3: 数据流架构 ---
  var chart3 = echarts.init(document.getElementById('chart-data-flow'), null, { renderer: 'svg' });
  chart3.setOption({
    animation: false,
    tooltip: { trigger: 'item', appendToBody: true },
    series: [{
      type: 'sankey',
      layout: 'none',
      emphasis: { focus: 'adjacency' },
      nodeAlign: 'left',
      layoutIterations: 0,
      data: [
        { name: 'TickFlow Free', itemStyle: { color: accent } },
        { name: 'AkShare', itemStyle: { color: accent2 } },
        { name: 'Parquet缓存', itemStyle: { color: '#d2a8ff' } },
        { name: '基本面CSV', itemStyle: { color: '#79c0ff' } },
        { name: '指标计算', itemStyle: { color: '#f0883e' } },
        { name: '指标缓存', itemStyle: { color: '#d2a8ff' } },
        { name: '筛选器', itemStyle: { color: '#f0883e' } },
        { name: '评分引擎', itemStyle: { color: accent } },
        { name: '回测引擎', itemStyle: { color: accent2 } },
        { name: '回测缓存', itemStyle: { color: '#d2a8ff' } },
        { name: '排名输出', itemStyle: { color: '#79c0ff' } },
        { name: 'CSV/Parquet', itemStyle: { color: muted } },
        { name: 'GUI', itemStyle: { color: accent } },
        { name: 'CLI', itemStyle: { color: accent2 } }
      ],
      links: [
        { source: 'TickFlow Free', target: 'Parquet缓存', value: 100 },
        { source: 'Parquet缓存', target: '指标计算', value: 100 },
        { source: '指标计算', target: '指标缓存', value: 80 },
        { source: '指标缓存', target: '筛选器', value: 80 },
        { source: '筛选器', target: '评分引擎', value: 60 },
        { source: 'AkShare', target: '基本面CSV', value: 30 },
        { source: '基本面CSV', target: '评分引擎', value: 30 },
        { source: '评分引擎', target: '回测引擎', value: 50 },
        { source: '回测引擎', target: '回测缓存', value: 50 },
        { source: '回测缓存', target: '排名输出', value: 50 },
        { source: '指标缓存', target: '排名输出', value: 30 },
        { source: '排名输出', target: 'CSV/Parquet', value: 80 },
        { source: 'CSV/Parquet', target: 'GUI', value: 50 },
        { source: 'CSV/Parquet', target: 'CLI', value: 30 }
      ],
      label: { color: ink, fontSize: 11 },
      lineStyle: { color: 'gradient', curveness: 0.5 }
    }]
  });
  window.addEventListener('resize', function() { chart3.resize(); });

  // --- Chart 4: 测试覆盖 ---
  var chart4 = echarts.init(document.getElementById('chart-test-coverage'), null, { renderer: 'svg' });
  chart4.setOption({
    animation: false,
    tooltip: { trigger: 'axis', appendToBody: true },
    grid: { left: 40, right: 40, top: 20, bottom: 80 },
    xAxis: {
      type: 'category',
      data: ['回归测试', '扫描逻辑', 'TickFlow', '性能', '模型v2', '加固', '扫描服务', '数据源', 'GUI进度', '代理', '排名v15'],
      axisLabel: { rotate: 45, color: muted, fontSize: 10 },
      axisLine: { lineStyle: { color: rule } }
    },
    yAxis: { type: 'value', name: '行数', nameTextStyle: { color: muted }, axisLine: { lineStyle: { color: rule } }, axisLabel: { color: muted } },
    series: [{
      type: 'bar',
      data: [2162, 244, 166, 156, 137, 132, 130, 130, 102, 66, 33],
      itemStyle: { color: accent },
      label: { show: true, position: 'top', color: muted, fontSize: 10 }
    }]
  });
  window.addEventListener('resize', function() { chart4.resize(); });
})();