(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var accent3 = style.getPropertyValue('--accent3').trim();
  var accent4 = style.getPropertyValue('--accent4').trim();
  var accent5 = style.getPropertyValue('--accent5').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart: Priority Impact vs Effort ---
  var chartPriority = echarts.init(document.getElementById('chart-priority'), null, { renderer: 'svg' });
  chartPriority.setOption({
    animation: false,
    tooltip: {
      trigger: 'item',
      appendToBody: true,
      formatter: function(p) {
        return '<strong>' + p.name + '</strong><br/>影响程度：' + p.value[0] + '/10<br/>实现难度：' + p.value[1] + '/10<br/>优先级：' + p.value[2];
      }
    },
    grid: { left: 60, right: 30, top: 40, bottom: 50 },
    xAxis: {
      name: '影响程度 →',
      nameLocation: 'middle',
      nameGap: 30,
      max: 10,
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    yAxis: {
      name: '实现难度 →',
      nameLocation: 'middle',
      nameGap: 40,
      max: 10,
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    series: [{
      type: 'scatter',
      symbolSize: function(data) {
        return data[2] === 'P0' ? 20 : data[2] === 'P1' ? 16 : data[2] === 'P2' ? 13 : 10;
      },
      data: [
        { value: [9, 4, 'P0'], name: '子进程改为进程内调用' },
        { value: [8, 3, 'P0'], name: 'Monkey-Patch重构' },
        { value: [7, 3, 'P0'], name: 'ScanResult拆分' },
        { value: [8, 1, 'P0'], name: 'Parquet加载' },
        { value: [6, 4, 'P1'], name: '包结构引入' },
        { value: [6, 3, 'P1'], name: '大函数拆分' },
        { value: [6, 3, 'P1'], name: '类型注解' },
        { value: [5, 2, 'P1'], name: '魔法字符串消除' },
        { value: [5, 2, 'P1'], name: '筛选防抖优化' },
        { value: [8, 8, 'P2'], name: 'Tkinter→Qt迁移' },
        { value: [5, 5, 'P2'], name: '依赖注入' },
        { value: [7, 5, 'P2'], name: '指标增量更新' },
        { value: [5, 4, 'P2'], name: '测试覆盖率' },
        { value: [5, 5, 'P2'], name: '插件化数据源' },
        { value: [3, 4, 'P3'], name: '深色模式' },
        { value: [4, 4, 'P3'], name: '内存优化' },
        { value: [3, 2, 'P3'], name: 'CI/CD增强' },
        { value: [3, 3, 'P3'], name: '详情侧边面板' },
        { value: [4, 3, 'P3'], name: '日志系统优化' },
        { value: [3, 2, 'P3'], name: '文档字符串' },
        { value: [4, 2, 'P3'], name: '错误处理策略' },
        { value: [4, 3, 'P3'], name: '并行下载优化' }
      ],
      itemStyle: {
        color: function(params) {
          var p = params.value[2];
          if (p === 'P0') return accent4;
          if (p === 'P1') return accent2;
          if (p === 'P2') return accent;
          return accent3;
        },
        opacity: 0.85
      },
      label: {
        show: true,
        formatter: '{b}',
        position: 'right',
        fontSize: 10,
        color: ink
      },
      emphasis: {
        scale: 1.5
      }
    }]
  });
  window.addEventListener('resize', function() { chartPriority.resize(); });

  // --- Chart: Radar - Code Quality by Module ---
  var chartRadar = echarts.init(document.getElementById('chart-radar'), null, { renderer: 'svg' });
  chartRadar.setOption({
    animation: false,
    tooltip: { trigger: 'item', appendToBody: true },
    legend: {
      bottom: 0,
      textStyle: { color: ink, fontSize: 12 }
    },
    radar: {
      center: ['50%', '48%'],
      radius: '65%',
      indicator: [
        { name: '类型注解', max: 10 },
        { name: '文档完整度', max: 10 },
        { name: '测试覆盖', max: 10 },
        { name: '代码复用', max: 10 },
        { name: '错误处理', max: 10 },
        { name: '模块内聚', max: 10 }
      ],
      axisName: { color: ink, fontSize: 11 },
      splitArea: { areaStyle: { color: ['rgba(22,119,255,0.02)', 'rgba(22,119,255,0.04)'] } }
    },
    series: [{
      type: 'radar',
      data: [
        {
          name: 'scanner.py',
          value: [7, 8, 5, 6, 7, 7],
          lineStyle: { color: accent, width: 2 },
          areaStyle: { color: accent + '20' },
          itemStyle: { color: accent }
        },
        {
          name: 'gui_core.py',
          value: [4, 5, 3, 4, 5, 5],
          lineStyle: { color: accent4, width: 2 },
          areaStyle: { color: accent4 + '20' },
          itemStyle: { color: accent4 }
        },
        {
          name: 'indicators.py',
          value: [8, 7, 6, 8, 7, 8],
          lineStyle: { color: accent3, width: 2 },
          areaStyle: { color: accent3 + '20' },
          itemStyle: { color: accent3 }
        },
        {
          name: 'downloader.py',
          value: [6, 7, 5, 7, 6, 7],
          lineStyle: { color: accent2, width: 2 },
          areaStyle: { color: accent2 + '20' },
          itemStyle: { color: accent2 }
        },
        {
          name: 'config.py',
          value: [8, 9, 4, 7, 6, 8],
          lineStyle: { color: accent5, width: 2 },
          areaStyle: { color: accent5 + '20' },
          itemStyle: { color: accent5 }
        }
      ]
    }]
  });
  window.addEventListener('resize', function() { chartRadar.resize(); });

  // --- Chart: Distribution Pie ---
  var chartDist = echarts.init(document.getElementById('chart-distribution'), null, { renderer: 'svg' });
  chartDist.setOption({
    animation: false,
    tooltip: { trigger: 'item', appendToBody: true, formatter: '{b}: {c} 项 ({d}%)' },
    legend: {
      bottom: 0,
      textStyle: { color: ink, fontSize: 12 }
    },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      center: ['50%', '45%'],
      avoidLabelOverlap: false,
      label: {
        show: true,
        position: 'outside',
        formatter: '{b}\n{d}%',
        color: ink,
        fontSize: 11
      },
      emphasis: {
        scale: true,
        scaleSize: 10
      },
      data: [
        { value: 8, name: 'GUI优化', itemStyle: { color: accent } },
        { value: 5, name: '架构优化', itemStyle: { color: accent2 } },
        { value: 5, name: '性能优化', itemStyle: { color: accent3 } },
        { value: 5, name: '代码质量', itemStyle: { color: accent5 } },
        { value: 5, name: '基础设施', itemStyle: { color: accent4 } }
      ]
    }]
  });
  window.addEventListener('resize', function() { chartDist.resize(); });
})();